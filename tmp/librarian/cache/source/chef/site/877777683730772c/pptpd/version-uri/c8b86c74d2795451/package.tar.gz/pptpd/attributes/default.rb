
default[:pptpd][:username]   = "user"
default[:pptpd][:password]   = "password"
default[:pptpd][:localip]   = "192.168.240.1"
default[:pptpd][:remoteip]   = "192.168.240.2-9"
default[:pptpd][:first_dns]   = "8.8.8.8"
default[:pptpd][:second_dns]   = "8.8.4.4"
